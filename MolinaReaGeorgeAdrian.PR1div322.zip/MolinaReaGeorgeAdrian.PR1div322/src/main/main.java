/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main;

import Exceptions.ExceptionHallazgoRepetido;
import java.time.LocalDate;
import model.Construccion;
import model.Epoca;
import model.Fosil;
import model.Hallazgo;
import model.HerramientaAntigua;
import model.Laboratorio;

/**
 *
 * @author User
 */
public class main {

    public static void main(String[] args)throws ExceptionHallazgoRepetido{
        
        
      Laboratorio Ins = new Laboratorio();
      Hallazgo hallazgo = new Fosil("reptil", true, "Argentina", LocalDate.of(1999, 2, 12), 4);
      Hallazgo hallazgo2 = new Construccion("Casa", Epoca.COLONIAL, "Argentina", LocalDate.of(1999, 2, 12), 8);
      Hallazgo hallazgo3 = new HerramientaAntigua("cobre", "picar", "Argentina", LocalDate.of(1999, 2, 12), 4);
      Hallazgo hallazgo4 = new Fosil("oso", true, "Argentina", LocalDate.of(1999, 2, 12), 11);
      Hallazgo hallazgo5 = new Fosil("reptil", true, "Argentina", LocalDate.of(1999, 2, 12), 11);

      
      System.out.println("=============== CONSIGNA AGREGAR EQUIPOS =================\n");
      try{
          Ins.registrar(hallazgo);
          Ins.registrar(hallazgo2);
          Ins.registrar(hallazgo3);
          Ins.registrar(hallazgo4);
          Ins.registrar(hallazgo5);
            
        
        }catch (ExceptionHallazgoRepetido e){
                      System.out.println("Error!!! "+ e.getMessage());}
        System.out.println("-------------");
        System.out.println("=============== MOSTRAR EQUIPOS =================\n");
        Ins.listarHallazgos();
        System.out.println("=============== Restaurar EQUIPOS =================\n");
        Ins.reconstruirHallazgos();
        System.out.println("=============== Analizar EQUIPOS =================\n");
        Ins.analizarHallazgos();
        System.out.println("=============== CONSIGNA FILTRO =================\n");
        Ins.filtroEpoca(Epoca.COLONIAL).forEach((a) -> System.out.println(a));
        System.out.println("=============== ESTADO CONSERVACION =================\n");
        Ins.mostrarEstadoConservacion(2, 5);
    }
}
