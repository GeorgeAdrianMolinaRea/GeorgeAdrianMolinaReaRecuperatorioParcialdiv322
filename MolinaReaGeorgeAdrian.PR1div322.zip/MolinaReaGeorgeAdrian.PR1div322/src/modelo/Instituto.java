
package modelo;

import Exceptions.HallazgoRepetidoException;
import java.util.ArrayList;


public class Instituto {
        private ArrayList <Hallazgo> instituto;

    public Instituto() {
        instituto = new ArrayList <>();
    }
    
    public void registrarNuevoHallazgo(Hallazgo hallazgo)throws HallazgoRepetidoException{
    if (instituto.contains(hallazgo)){
        throw new HallazgoRepetidoException("Este hallazgo ya se encuentra registrado");}
    instituto.add(hallazgo);
    }
    
    public void listarTodosLosHallazgos(){
        for (Hallazgo hallazgo:instituto){
            System.out.println(hallazgo);
        }
    }
    
    public void filtrarEpoca(Epoca epoca){
        for (Hallazgo hallazgo:instituto){
            if (hallazgo instanceof Construccion){
                Construccion construccion = (Construccion) hallazgo;
                if (construccion.getEpoca() == epoca){
                    System.out.println(construccion);
                }
                
            };
        };
    };
    public void analisisLaboratorio(){
    for (Hallazgo hallazgo:instituto){
        if (hallazgo instanceof Fosil){
        ((Fosil)hallazgo).analizar();
        }
        if (hallazgo instanceof HerramientaAntigua){
            ((HerramientaAntigua)hallazgo).analizar();
        }
    }
    }
    public void realizarRestauracion(){
    for (Hallazgo hallazgo:instituto){
        if (hallazgo instanceof Construccion){
        ((Construccion)hallazgo).reconstruir();
        }
    }
    }
    
    public void estadodeConservacionAnalisis(int min,int max){
        for(Hallazgo hallazgo: instituto){
            if(hallazgo.estado_conservacion > min && hallazgo.estado_conservacion < max){
                System.out.println(hallazgo);
            }
        }
    }
    
}

