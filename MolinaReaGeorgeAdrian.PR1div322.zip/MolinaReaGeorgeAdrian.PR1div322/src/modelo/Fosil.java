
package modelo;

import interfaces.Analizable;
import java.time.LocalDate;


public class Fosil extends Hallazgo implements Analizable{
    private String especie;
    private boolean completo;

    public Fosil(String especie, boolean completo, String ubicacion, String informacion, LocalDate fecha_descubrimiento, String estado_conservacion, int id) {
        super(ubicacion, informacion, fecha_descubrimiento, estado_conservacion, id);
        this.especie = especie;
        this.completo = completo;
    }
    
    @Override
    public void analizar(){
        System.out.println("El fosil esta siendo analizado");
    };


    


    
    
    
    
    
}
