
package modelo;

import java.time.LocalDate;


public abstract class Hallazgo {
    private String ubicacion;
    private String informacion;
    private LocalDate fecha_descubrimiento;
    private String estado_conservacion;
    private int id;
    private static int ESTADO_MAX = 10;
    private static int ESTADO_MIN = 1;

    public Hallazgo(String ubicacion, String informacion, LocalDate fecha_descubrimiento, String estado_conservacion, int id) {
        this.ubicacion = ubicacion;
        this.informacion = informacion;
        this.fecha_descubrimiento = fecha_descubrimiento;
        this.estado_conservacion = estado_conservacion;
        this.id = id;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
            }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
        Hallazgo otro = (Hallazgo) obj; 
        return ubicacion.equals(otro.ubicacion) && fecha_descubrimiento.equals(otro.fecha_descubrimiento);
    }
    

    
    
    
}
