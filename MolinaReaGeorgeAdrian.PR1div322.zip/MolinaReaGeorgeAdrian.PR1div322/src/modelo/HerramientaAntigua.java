
package modelo;

import java.time.LocalDate;

public class HerramientaAntigua extends Hallazgo{
    private String material;
    private String uso_probable;

    public HerramientaAntigua(String material, String uso_probable, String ubicacion, String informacion, LocalDate fecha_descubrimiento, String estado_conservacion, int id) {
        super(ubicacion, informacion, fecha_descubrimiento, estado_conservacion, id);
        this.material = material;
        this.uso_probable = uso_probable;
    }


    
    
    
    
}
