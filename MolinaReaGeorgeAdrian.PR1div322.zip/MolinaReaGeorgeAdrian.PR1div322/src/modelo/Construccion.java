
package modelo;

import interfaces.Reconstruible;
import java.time.LocalDate;


public class Construccion extends Hallazgo implements Reconstruible{
    private String tipo_edificacion;
    private Epoca epoca;

    public Construccion(String tipo_edificacion, Epoca epoca, String ubicacion, String informacion, LocalDate fecha_descubrimiento, String estado_conservacion, int id) {
        super(ubicacion, informacion, fecha_descubrimiento, estado_conservacion, id);
        this.tipo_edificacion = tipo_edificacion;
        this.epoca = epoca;
    }

    @Override
    public void reconstruir() {
        System.out.println("La construccion se esta reconstruyendo");
    }
    


    


    
    
  
    
}
