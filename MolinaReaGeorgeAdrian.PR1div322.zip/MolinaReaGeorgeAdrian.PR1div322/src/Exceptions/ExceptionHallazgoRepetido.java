package Exceptions;





public class ExceptionHallazgoRepetido extends Exception{

    public ExceptionHallazgoRepetido(String message) {
        super(message);
    } 
}
