
package servicio;


public interface Restaurable {
    void restaurable();
}
