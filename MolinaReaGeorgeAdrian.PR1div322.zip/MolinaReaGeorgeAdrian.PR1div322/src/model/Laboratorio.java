
package model;

import Exceptions.ExceptionHallazgoRepetido;
import model.HerramientaAntigua;
import model.Hallazgo;
import model.Fosil;
import model.Epoca;
import model.Construccion;
import java.util.ArrayList;


public class Laboratorio {
    ArrayList <Hallazgo> lista = new ArrayList<>();
    
    
    public void registrar(Hallazgo hallazgo)throws ExceptionHallazgoRepetido{
        if(hallazgo == null){
            System.out.println("Error");
        }
        else{for(Hallazgo item:lista){
            if(item.equals(hallazgo))
                throw new ExceptionHallazgoRepetido("Hallazgo repetido"){};
        }lista.add(hallazgo);
        }
    }
    
    public void listarHallazgos(){
        for(Hallazgo item : lista){
            System.out.println(item);
        }
    }
    
    public void analizarHallazgos(){
        for(Hallazgo item : lista){
            if(item instanceof Fosil){
                ((Fosil)item).analizable();
            }
            else if(item instanceof HerramientaAntigua){
                ((HerramientaAntigua)item).analizable();
            }
            else System.out.println("La contruccion no puede ser analizada");
        }
    }
    
    public void reconstruirHallazgos(){
        for(Hallazgo item : lista){
            if(item instanceof Construccion){
                ((Construccion)item).restaurable();
            }
        }
    }
    
    public ArrayList<Hallazgo> filtroEpoca(Epoca epoca){
        ArrayList<Hallazgo> filtrado = new ArrayList<>();
        for(Hallazgo hallazgo : lista){
            if(hallazgo instanceof Construccion){
                if(((Construccion)hallazgo).getEpoca() == epoca){
                    filtrado.add(hallazgo);
                }
            }
        }return filtrado;
    }
    public void mostrarEstadoConservacion(int estadocons, int estadocons2){
        for(Hallazgo hallazgo : lista){
            if(hallazgo.getEstadoConservacion() >= estadocons && hallazgo.getEstadoConservacion() <= estadocons2){
                System.out.println(hallazgo);
            }
        }
    }
}
