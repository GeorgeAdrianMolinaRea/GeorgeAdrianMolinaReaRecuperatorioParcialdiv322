/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import model.Hallazgo;
import java.time.LocalDate;
import servicio.Analizable;

/**
 *
 * @author User
 */
public class HerramientaAntigua extends Hallazgo implements Analizable{
    private String material;
    private String uso;

    public HerramientaAntigua(String material, String uso, String ubicacion, LocalDate fechaDescubrimiento, int estadoConservacion) {
        super(ubicacion, fechaDescubrimiento, estadoConservacion);
        this.material = material;
        this.uso = uso;
    }

    

    @Override
    public void analizable() {
        System.out.println("La herramienta esta siendo analizada...");
    }

    @Override
    public String toString() {
        return "HerramientaAntigua{" + "material=" + material + ", uso=" + uso + super.toString() +'}';
    }

    
    
    
}
