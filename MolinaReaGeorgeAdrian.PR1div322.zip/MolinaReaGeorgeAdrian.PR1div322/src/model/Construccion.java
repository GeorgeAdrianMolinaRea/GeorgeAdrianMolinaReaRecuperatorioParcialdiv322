
package model;

import java.time.LocalDate;
import model.Epoca;
import model.Hallazgo;
import servicio.Restaurable;

public class Construccion extends Hallazgo implements Restaurable{
    private String tipoEdificacion;
    private Epoca epoca;

    public Construccion(String tipoEdificacion, Epoca epoca, String ubicacion, LocalDate fechaDescubrimiento, int estadoConservacion) {
        super(ubicacion, fechaDescubrimiento, estadoConservacion);
        this.tipoEdificacion = tipoEdificacion;
        this.epoca = epoca;
    }

    @Override
    public void restaurable() {
        System.out.println("La " + tipoEdificacion + " esta siendo restaurado...");
    }

    @Override
    public String toString() {
        return "Construccion{" + "tipoEdificacion=" + tipoEdificacion + ", epoca=" + epoca + super.toString();
    }

    public Epoca getEpoca() {
        return epoca;
    }
}
