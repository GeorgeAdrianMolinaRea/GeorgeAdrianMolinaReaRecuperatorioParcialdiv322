
package model;

import java.time.LocalDate;
import model.Hallazgo;
import servicio.Analizable;


public class Fosil extends Hallazgo implements Analizable{
    private String especie;
    private boolean completo;

    public Fosil(String especie, boolean completo, String ubicacion, LocalDate fechaDescubrimiento, int estadoConservacion) {
        super(ubicacion, fechaDescubrimiento, estadoConservacion);
        this.especie = especie;
        this.completo = completo;
    }

    @Override
    public void analizable() {
        System.out.println("El fosil esta siendo analizado...");
    }

    @Override
    public String toString() {
        return "Fosil{" + "especie=" + especie + ", completo=" + completo + super.toString();
    }
    
    
}
