
package model;

import java.time.LocalDate;


public class Hallazgo {
    private String ubicacion;
    private LocalDate fechaDescubrimiento;
    private int estadoConservacion;
    private static final int CONSMAX = 10; 
    private static final int CONSMIN = 1; 
    private static int contador = 50000;
    private int id;

    public Hallazgo(String ubicacion, LocalDate fechaDescubrimiento, int estadoConservacion) {
        this.ubicacion = ubicacion;
        this.fechaDescubrimiento = fechaDescubrimiento;
        this.estadoConservacion = estadoConservacion;
        this.id = contador++;
        validarCons(estadoConservacion);
    }

    private void validarCons(int estadocons){
        if (estadocons < 1 && estadocons > 10){
            throw new IllegalArgumentException();        
        };
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
            }
        if (obj == null || getClass() != obj.getClass()){
            return false;
        }
        Hallazgo otro = (Hallazgo) obj; 
        return ubicacion.equals(otro.ubicacion) && fechaDescubrimiento.equals(otro.fechaDescubrimiento);
    }

    @Override
    public String toString() {
        return "ubicacion=" + ubicacion + ", fechaDescubrimiento=" + fechaDescubrimiento + ", estadoConservacion=" + estadoConservacion + ", id=" + id;
    }

    public int getEstadoConservacion() {
        return estadoConservacion;
    }
}
